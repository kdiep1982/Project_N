<?php
include('header.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="en-us" http-equiv="Content-Language" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Untitled 1</title>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp; </p>
<table style="width: 60%" align="center" border="0">
	<tr>
		<td style="width: 50%">
		<img alt="" height="128" src="images/itunes_logo_op_800x257.jpg" style="float: left" width="348" />
		<a href="http://dm-mediainfo-2/battle/main.php"><img alt="" height="128" src="images/NetflixTile.png" style="float: right" width="348" class="auto-style1" /></a>
		</td>
	</tr>
</table>

</body>

</html>

