#!/usr/bin/php

<?php
if(!file_exists('/mnt/fs4_encoding/04-for-qc/test/gossip_girl')) {
	$output=shell_exec('mkdir /mnt/fs4_encoding/04-for-qc/test/gossip_girl');
}
?>
